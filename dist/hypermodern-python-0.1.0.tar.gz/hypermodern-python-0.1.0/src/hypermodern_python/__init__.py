# src/hypermodern_python/__init__.py
"""The hypermodern Python project."""
__version__ = "0.1.0"
