# hypermodern-python
[![Tests](https://github.com/JayDiehl/hypermodern-python/workflows/Tests/badge.svg)](https://github.com/JayDiehl/hypermodern-python/actions?workflow=Tests)
[![Codecov](https://codecov.io/gh/JayDiehl/hypermodern-python/branch/master/graph/badge.svg)](https://codecov.io/gh/JayDiehl/hypermodern-python)
