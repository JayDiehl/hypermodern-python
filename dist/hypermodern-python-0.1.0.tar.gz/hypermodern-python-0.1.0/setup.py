# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['hypermodern_python']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.0,<9.0',
 'desert>=2022.9.22,<2023.0.0',
 'marshmallow>=3.21.1,<4.0.0',
 'requests>=2.31.0,<3.0.0']

entry_points = \
{'console_scripts': ['hypermodern-python = hypermodern_python.console:main']}

setup_kwargs = {
    'name': 'hypermodern-python',
    'version': '0.1.0',
    'description': 'The hypermodern Python project',
    'long_description': '# hypermodern-python\n[![Tests](https://github.com/JayDiehl/hypermodern-python/workflows/Tests/badge.svg)](https://github.com/JayDiehl/hypermodern-python/actions?workflow=Tests)\n[![Codecov](https://codecov.io/gh/JayDiehl/hypermodern-python/branch/master/graph/badge.svg)](https://codecov.io/gh/JayDiehl/hypermodern-python)\n',
    'author': 'JayDiehl',
    'author_email': 'Jay.Diehl@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/JayDiehl/hypermodern-python',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
